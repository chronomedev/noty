<?php


    echo"<script>window.location.assign('main.html')</script>"


?>