<?php

    session_start();
    echo $_SESSION['passing_id'];







?>